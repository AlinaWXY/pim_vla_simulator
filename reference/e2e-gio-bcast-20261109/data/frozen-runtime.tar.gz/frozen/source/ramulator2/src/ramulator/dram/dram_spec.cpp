#include "ramulator/dram/dram_spec.h"

namespace Ramulator {

BankTarget bank_target_from_name(std::string_view name) {
  if (name == "single") {
    return BankTarget::Single;
  }
  if (name == "all") {
    return BankTarget::All;
  }
  if (name == "same_bank") {
    return BankTarget::SameBank;
  }
  if (name == "pair") {
    return BankTarget::Pair;
  }
  throw std::runtime_error("Unknown bank target: " + std::string(name));
}

void DRAMSpec::load_config(const ConfigNode& config) {
  const ConfigNode dram = config["dram"];

  // Organization
  channel_width = dram["channel_width"].as<int>();
  ConfigNode data_payload_node = dram["data_payload_bytes"];
  data_payload_bytes = data_payload_node ? data_payload_node.as<int>() : -1;
  ConfigNode org = dram["org"];
  organization.dq = org["dq"].as<int>();
  ConfigNode count_node = org["count"];
  const auto& counts = count_node.seq();
  organization.level_sizes.resize(counts.size());
  for (size_t i = 0; i < counts.size(); i++) {
    organization.level_sizes[i] = counts[i].as<int>();
  }
  // Each controller handles a single channel
  if (organization.level_sizes[0] != 1) {
    throw std::runtime_error(
        "DRAMSpec: level_sizes[0] (Channel) must be 1 — "
        "multi-channel is configured at the system level, not in the DRAM spec. "
        "Got: " + std::to_string(organization.level_sizes[0]));
  }

  // Timing values
  ConfigNode timing_node = dram["timing"];
  const auto& timing = timing_node.seq();
  timing_vals.resize(timing.size());
  for (size_t i = 0; i < timing.size(); i++) {
    timing_vals[i] = timing[i].as<int>();
  }

  // Command bus cycle counts (pre-computed by Python)
  command_cycles.assign(command_count, 1);
  ConfigNode command_cycles_node = dram["command_cycles"];
  if (command_cycles_node) {
    const auto& cycles = command_cycles_node.seq();
    for (size_t i = 0; i < cycles.size() && i < command_cycles.size(); i++) {
      command_cycles[i] = cycles[i].as<int>();
    }
  }
  command_slot_cycles = dram["command_slot_cycles"].as<int>(1);

  // [parent command, [[primitive command, offset, [[level, address], ...]], ...]]
  command_expansions.resize(command_count);
  ConfigNode expansions_node = dram["command_expansions"];
  if (expansions_node) {
    for (const auto& entry : expansions_node.seq()) {
      const auto& e = entry.seq();
      int parent = e[0].as<int>();
      if (parent < 0 || parent >= command_count) throw std::runtime_error("Invalid expansion parent");
      Clk_t previous = -1;
      for (const auto& primitive : e[1].seq()) {
        const auto& p = primitive.seq();
        CommandExpansion x{p[0].as<int>(), p[1].as<Clk_t>(), {}};
        if (x.command < 0 || x.command >= command_count || x.command == parent || x.offset < previous || x.offset < 0)
          throw std::runtime_error("Invalid or unsorted command expansion");
        previous = x.offset;
        for (const auto& patch : p[2].seq()) {
          const auto& a = patch.seq();
          int level = a[0].as<int>(), value = a[1].as<int>();
          if (level < 0 || level >= level_count || value < 0 || value >= organization.level_sizes[level])
            throw std::runtime_error("Invalid expansion address override");
          x.address_overrides.emplace_back(level, value);
        }
        command_expansions[parent].push_back(std::move(x));
      }
    }
  }

  // Config-time mode switches (pre-resolved by Python)
  ConfigNode modes_node = dram["modes"];
  if (modes_node) {
    for (const auto& [name, value] : modes_node.map()) {
      modes[name] = value.as<std::string>();
    }
  }

  // Read latency (pre-computed by Python)
  read_latency = dram["read_latency"].as<int>();

  // Timing constraints (pre-computed by Python)
  timing_cons.resize(level_count, std::vector<std::vector<TimingConsEntry>>(command_count));

  ConfigNode tc_node = dram["timing_constraints"];
  for (const auto& entry : tc_node.seq()) {
    const auto& f = entry.seq();
    int level = f[0].as<int>();
    int latency = f[3].as<int>();
    int window = f.size() > 4 ? f[4].as<int>() : 1;
    bool sibling = f.size() > 5 ? f[5].as<bool>() : false;
    int history_group = f.size() > 6 ? f[6].as<int>() : -1;
    for (const auto& p : f[1].seq()) {
      for (const auto& fc : f[2].seq()) {
        timing_cons[level][p.as<int>()].push_back(
            {fc.as<int>(), latency, window, sibling, history_group});
      }
    }
  }

  // Precompute sibling-constraint flags to skip unnecessary traversal
  has_sibling_cons.assign(level_count, std::vector<int8_t>(command_count, 0));
  for (int lvl = 0; lvl < level_count; ++lvl) {
    for (int cmd = 0; cmd < command_count; ++cmd) {
      for (const auto& t : timing_cons[lvl][cmd]) {
        if (t.sibling) {
          has_sibling_cons[lvl][cmd] = 1;
          break;
        }
      }
    }
  }
}

std::map<std::string, DRAMSpec::Creator>& DRAMSpec::registry() {
  static std::map<std::string, Creator> r;
  return r;
}

bool DRAMSpec::register_standard(const std::string& name, Creator c) {
  registry()[name] = std::move(c);
  return true;
}

std::unique_ptr<DRAMSpec> DRAMSpec::create(const std::string& name, const ConfigNode& config) {
  auto it = registry().find(name);
  if (it == registry().end()) {
    throw std::runtime_error("Unknown DRAM standard: " + name);
  }
  auto spec = it->second(config);
  spec->standard_name = name;

  // Per-configuration bank targets override the command defaults: [command, pattern, level, xor_mask]
  const ConfigNode dram = config["dram"];
  ConfigNode bt_node = dram["bank_targets"];
  if (bt_node) {
    for (const auto& entry : bt_node.seq()) {
      const auto& e = entry.seq();
      int cmd = e[0].as<int>();
      spec->bank_targets[cmd] = bank_target_from_name(e[1].as<std::string>());
      spec->pair_rules[cmd] = {e[2].as<int>(), e[3].as<int>()};
    }
  }
  return spec;
}

}  // namespace Ramulator
