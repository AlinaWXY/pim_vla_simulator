#include <string>

#include "ramulator/base/base.h"
#include "ramulator/controller/impl/lpddr_controller_base.h"
#include "ramulator/dram/dram_spec.h"

namespace Ramulator {

class LPDDR5Controller final : public LPDDRControllerBase {
  RAMULATOR_REGISTER_IMPLEMENTATION_DERIVED(IController, LPDDR5Controller, LPDDRControllerBase, "LPDDR5")

 public:
  void init() override {
    LPDDRControllerBase::init();

    std::string wck_sync_mode_str;
    RAMULATOR_PARSE_PARAM(wck_sync_mode_str, std::string, "wck_sync_mode").default_val("need_sync");
    m_wck_sync_mode = parse_wck_sync_mode(wck_sync_mode_str);

    const auto& spec = *m_device.m_spec;
    m_cmd_act1 = spec.get_command_id("ACT1");
    m_cmd_act2 = spec.get_command_id("ACT2");
    m_cmd_cas_rd = spec.get_command_id("CAS_RD");
    m_cmd_cas_wr = spec.get_command_id("CAS_WR");
    m_cmd_rd = spec.get_command_id("RD");
    m_cmd_wr = spec.get_command_id("WR");
    m_cmd_rda = spec.get_command_id("RDA");
    m_cmd_wra = spec.get_command_id("WRA");

    m_nAAD = spec.get_timing_value("nAAD");
    m_read_latency = spec.get_timing_value("nCL");
    m_write_latency = spec.get_timing_value("nCWL");
    m_burst_cycles = spec.get_timing_value("nBL_max");
    m_nWCKPST = spec.get_timing_value("nWCKPST");
    m_cas_deadline_guard = 1;
  }
};

}  // namespace Ramulator
