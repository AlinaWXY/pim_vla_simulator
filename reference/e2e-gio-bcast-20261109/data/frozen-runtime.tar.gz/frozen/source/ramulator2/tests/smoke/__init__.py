"""Smoke test suite."""
