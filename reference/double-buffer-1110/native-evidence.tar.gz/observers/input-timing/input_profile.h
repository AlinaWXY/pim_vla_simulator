#pragma once

#include <cstdlib>
#include <fstream>

namespace PimVla {
namespace {
class InputProfile {
  enum Mode { Other, Write, Broadcast, Direct, ModeCount };
  static constexpr std::array<const char*, ModeCount> names{
      "other", "wr_upload", "localrd_bcast", "wrgb"};

  struct Bucket {
    Clock begin = -1, first_data = -1, end = 0, act_begin = -1;
    uint64_t groups = 0, window_ck = 0, from_data_ck = 0, act_to_data_ck = 0;
    uint64_t act1 = 0, act2 = 0, actab = 0, ext_act_ca = 0, private_act_ca = 0;
    uint64_t pre_ca = 0, wr = 0, wrgb = 0, localrd = 0, bcast = 0;
    uint64_t dq_ck = 0, localrd_ck = 0, bcast_ck = 0;
    uint64_t gpu_rd = 0, gpu_wr = 0, gpu_other = 0;
    uint64_t gpu_admit = 0, gpu_reject = 0, reject_wrgb = 0;
    uint64_t wrgb_issue_during_mac = 0, wrgb_dq_during_mac_ck = 0;

    void close() {
      if (first_data >= 0) {
        ++groups;
        window_ck += end - begin;
        from_data_ck += end - first_data;
      }
      begin = first_data = act_begin = -1;
      end = 0;
    }
  };

  struct Stage {
    Clock start = 0, mac_end = 0;
    bool operand_stage = false;
    Mode active = Other;
    std::array<Bucket, ModeCount> buckets{};
  };

  const char* output = std::getenv("PIM_INPUT_PROFILE");
  std::array<std::vector<Stage>, 16> channels;
  std::ofstream trace;

  static Mode head_mode(const PIMController& c) {
    bool inner = c.descriptor_index >= 0;
    const auto& cursor = inner ? c.inner : c.top;
    if (cursor.issued()) return Other;
    const auto& op = cursor.ops->at(cursor.next);
    if (op.name == "WRGB" && op.epoch.ends_with("_stream")) return Direct;
    if (op.name == "WR" && op.epoch.ends_with("_input")) return Write;
    if (inner && (op.name == "ACTAB" ||
        (op.tensor_fragment >= 0 && (op.name == "LOCALRD" || op.name == "BCAST"))))
      return Broadcast;
    return Other;
  }

  static Mode gpu_mode(const PIMController& c, const Stage& stage, Clock clk) {
    Mode mode = head_mode(c);
    if (mode == Other && stage.active != Other && stage.buckets[stage.active].end > clk)
      return stage.active;
    return mode;
  }

  static Clock overlap(Clock a0, Clock a1, Clock b0, Clock b1) {
    return std::max<Clock>(0, std::min(a1,b1) - std::max(a0,b0));
  }

public:
  InputProfile() {
    if (const char* path = std::getenv("PIM_INPUT_TRACE")) {
      trace.open(path);
      trace << "stage,phase,ck,command,rank,bg,bank,row,column,operation,op_id,source,dq_start,dq_end\n";
    }
  }

  void set_stage(const PIMController& c, Clock clk, const std::string& name) {
    if (!output) return;
    auto& stages = channels.at(c.channel);
    stages.resize(c.stage + 1);
    auto& s = stages.back();
    s.start = clk;
    s.operand_stage = name == "qkv" || name == "pv" || name == "o" ||
                      name == "gate_up" || name == "down";
  }

  void decision(const PIMController& c, const Candidate& p, Clock clk, bool denied) {
    if (!output || c.stage < 0 || c.policy != "pim_head" || c.fused) return;
    auto& s = channels.at(c.channel).at(c.stage);
    auto& b = s.buckets[gpu_mode(c,s,clk)];
    if (denied) {
      ++b.gpu_reject;
      if (p.cmd >= 0 && c.device.m_spec->command_names[p.cmd] == "WRGB") ++b.reject_wrgb;
    } else {
      ++b.gpu_admit;
    }
  }

  void issue(const PIMController& c, int cmd, const AddrVec_t& addr, Clock clk,
             Candidate::Source source) {
    if (!output || c.stage < 0) return;
    auto& s = channels.at(c.channel).at(c.stage);
    const auto& name = c.device.m_spec->command_names[cmd];
    const auto& m = c.info[cmd];
    bool pim = addr[1] == 1 && source != Candidate::REFRESH;
    Mode mode = s.operand_stage ? (pim ? head_mode(c) : gpu_mode(c,s,clk)) : Other;
    auto& b = s.buckets[mode];
    if (pim && mode != s.active) {
      s.buckets[s.active].close();
      s.active = mode;
    }
    if (pim && mode != Other && b.begin < 0) b.begin = mode == Write ? s.start : clk;

    if (pim && (name.starts_with("ACT1") || name.starts_with("ACT2") ||
                name.starts_with("ACTAB"))) {
      b.act1 += name.starts_with("ACT1");
      b.act2 += name.starts_with("ACT2");
      b.actab += name.starts_with("ACTAB");
      b.ext_act_ca += m.external_ca;
      b.private_act_ca += m.private_ca;
      if (b.act_begin < 0 && !name.starts_with("ACT2")) b.act_begin = clk;
    }
    if (pim && name.starts_with("PRE")) b.pre_ca += m.external_ca + m.private_ca;

    if (pim && mode != Other) {
      bool wr = name == "WR", wrgb = name == "WRGB";
      bool rd = name == "LOCALRD_LOCAL", bc = name == "BCAST_LOCAL";
      if (wr || wrgb || rd || bc) {
        if (b.first_data < 0) b.first_data = clk;
        b.end = std::max(b.end, clk + m.completion);
        if (b.act_begin >= 0 && (wr || rd)) {
          b.act_to_data_ck += clk - b.act_begin;
          b.act_begin = -1;
        }
        b.wr += wr;
        b.wrgb += wrgb;
        b.localrd += rd;
        b.bcast += bc;
        b.dq_ck += m.burst;
        if (rd) b.localrd_ck += m.completion;
        if (bc) b.bcast_ck += m.completion;
        if (wrgb && clk < s.mac_end) {
          ++b.wrgb_issue_during_mac;
          b.wrgb_dq_during_mac_ck += overlap(clk + m.latency, clk + m.latency + m.burst,
                                             clk, s.mac_end);
        }
      }
    }
    if (pim && name.starts_with("MACAB")) {
      s.mac_end = clk + m.completion;
      auto& direct = s.buckets[Direct];
      for (const auto& burst : c.checker.bursts)
        if (burst.stage == c.stage && c.device.m_spec->command_names[burst.command] == "WRGB")
          direct.wrgb_dq_during_mac_ck += overlap(burst.start,burst.end,clk,s.mac_end);
    }
    if (addr[1] == 0 && source != Candidate::REFRESH) {
      if (m.direction == 'R') ++b.gpu_rd;
      else if (m.direction == 'W') ++b.gpu_wr;
      else ++b.gpu_other;
    }
    if (trace.is_open() && c.channel == 0 && c.stage < 9 && mode != Other) {
      const auto& cur = c.descriptor_index >= 0 ? c.inner : c.top;
      const Operation* op = cur.issued() ? nullptr : &cur.ops->at(cur.next);
      trace << c.stage << ',' << names[mode] << ',' << clk << ',' << name;
      for (size_t i = 1; i < addr.size(); ++i) trace << ',' << addr[i];
      trace << ',' << (op ? op->name : "") << ',' << (op ? op->id : -1)
            << ',' << source << ',' << (m.direction ? clk + m.latency : -1)
            << ',' << (m.direction ? clk + m.latency + m.burst : -1) << '\n';
    }
  }

  ~InputProfile() {
    if (!output) return;
    std::ofstream out(output);
    out << "channel,stage,phase,groups,window_ck,from_data_ck,act_to_data_ck,act1,act2,actab,"
           "ext_act_ca,private_act_ca,pre_ca,wr,wrgb,localrd,bcast,dq_ck,localrd_ck,bcast_ck,"
           "gpu_rd,gpu_wr,gpu_other,gpu_admit,gpu_reject,reject_wrgb,"
           "wrgb_issue_during_mac,wrgb_dq_during_mac_ck\n";
    for (size_t ch = 0; ch < channels.size(); ++ch)
      for (size_t sid = 0; sid < channels[ch].size(); ++sid) {
        auto& stage = channels[ch][sid];
        for (int mode = 0; mode < ModeCount; ++mode) {
          auto& b = stage.buckets[mode];
          b.close();
          out << ch << ',' << sid << ',' << names[mode];
          for (auto n : {b.groups,b.window_ck,b.from_data_ck,b.act_to_data_ck,b.act1,b.act2,
                         b.actab,b.ext_act_ca,b.private_act_ca,b.pre_ca,b.wr,b.wrgb,b.localrd,
                         b.bcast,b.dq_ck,b.localrd_ck,b.bcast_ck,b.gpu_rd,b.gpu_wr,b.gpu_other,
                         b.gpu_admit,b.gpu_reject,b.reject_wrgb,b.wrgb_issue_during_mac,
                         b.wrgb_dq_during_mac_ck}) out << ',' << n;
          out << '\n';
        }
      }
    out.close();
    if (!out) std::abort();
  }
};

InputProfile input_profile;
}
}
