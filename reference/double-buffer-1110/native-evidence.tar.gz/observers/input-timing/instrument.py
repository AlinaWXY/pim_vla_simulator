from pathlib import Path
import sys


source, target = map(Path, sys.argv[1:])
code = source.read_text()
replacements = {
    '#include "ramulator/controller/impl/pim_model.h"':
        '#include "ramulator/controller/impl/pim_model.h"\n#include "input_profile.h"',
    "  checker.set_stage(clk,stage_id);":
        "  checker.set_stage(clk,stage_id);\n  input_profile.set_stage(*this,clk,name);",
    "    issue(a.cmd,a.addr,clk,stage);a.cmd=-1;a.deadline=NEVER;return clk;":
        "    const int act2_cmd=a.cmd;\n"
        "    issue(act2_cmd,a.addr,clk,stage);\n"
        "    input_profile.issue(*this,act2_cmd,a.addr,clk,Candidate::ACT2);\n"
        "    a.cmd=-1;a.deadline=NEVER;return clk;",
    "  else if(can_issue(gpu)&&!protect_pim(gpu,pim,clk))chosen=gpu;":
        "  else if(can_issue(gpu)) {\n"
        "    bool denied=protect_pim(gpu,pim,clk);\n"
        "    input_profile.decision(*this,pim,clk,denied);\n"
        "    if(!denied)chosen=gpu;\n"
        "    else if(can_issue(pim))chosen=pim;\n"
        "  }",
    "    issue(chosen.cmd,chosen.addr,clk,stage);":
        "    issue(chosen.cmd,chosen.addr,clk,stage);\n"
        "    input_profile.issue(*this,chosen.cmd,chosen.addr,clk,chosen.source);",
}
for before, after in replacements.items():
    if code.count(before) != 1:
        raise ValueError(f"expected one instrumentation anchor: {before}")
    code = code.replace(before, after)
target.write_text(code)
