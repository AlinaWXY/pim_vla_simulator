#pragma once

#include <cstdlib>
#include <fstream>
#include <map>

namespace PimVla {
namespace {
class GapProfile {
  struct Interval { Clock start, end; };
  struct Mac { Clock start, end; int batch; };
  struct Gpu { Clock issue, start, end; };
  struct Channel {
    std::string op;
    bool fused = false;
    int stage = -1, tile = 0, last_fragment = -1, views = 1;
    std::vector<Gpu> gpu;
    std::vector<Mac> macs;
    std::map<int, Clock> ready;
    Clock last_wr = -1, act_start = -1, act_ready = -1;
    bool refresh = false;
    std::vector<Interval> ca;
  };
  struct EStats {
    uint64_t accepted = 0, columns = 0, issued_mac = 0, issued_both = 0,
             issued_loading = 0, issued_final = 0, dq = 0, dq_mac = 0,
             dq_both = 0, bursts_wholly_both = 0, bursts_partly_both = 0;
  };
  struct GStats {
    uint64_t pairs = 0, gaps = 0, idle = 0, act_gaps = 0, act_gap_ck = 0,
             mixed_gaps = 0, mixed_ck = 0, act_window_ck = 0,
             rd_payload = 0, wr_payload = 0, rd_gaps = 0, wr_gaps = 0,
             clean_rd_payload = 0, clean_wr_payload = 0,
             clean_rd_gaps = 0, clean_wr_gaps = 0, gpu_columns = 0,
             upload_wr = 0;
  };

  const char* output = std::getenv("PIM_GAP_PROFILE");
  std::array<Channel, 16> channels;
  std::map<std::string, EStats> e;
  std::map<std::string, GStats> g;
  Clock wr_to_rd = -1, rd_to_wr = 0, wr_to_wr = 0, read_step = 0, write_step = 0;

  static bool operand(const std::string& op) {
    return op == "qkv" || op == "pv" || op == "o" || op == "gate_up" || op == "down";
  }

  static int batch_key(int tile, int fragment, int views) {
    return tile * 1024 + fragment / views;
  }

  static Clock clipped(Clock start, Clock end, Clock lo, Clock hi) {
    return std::max<Clock>(0,std::min(end,hi)-std::max(start,lo));
  }

  // Greedy earliest issue yields the maximum homogeneous burst count under
  // the stated column cadence and frozen CA intervals.
  static uint64_t capacity(Clock lo, Clock hi, Clock stride, const std::vector<Interval>& ca) {
    uint64_t count = 0;
    for (const auto& cmd : ca) {
      Clock last = std::min(hi,cmd.start-1);
      if (lo <= last) {
        auto n = (last-lo)/stride+1;
        count += n;
        lo += n*stride;
      }
      lo = std::max(lo,cmd.end);
      if (lo > hi) return count;
    }
    if (lo <= hi) count += (hi-lo)/stride+1;
    return count;
  }

  void finish_e(Channel& c) {
    if (c.stage < 0 || c.fused) return;
    auto& t = e[c.op];
    size_t issue_mac = 0, dq_mac = 0;
    for (const auto& gpu : c.gpu) {
      ++t.accepted;
      bool column = gpu.end > gpu.start;
      t.columns += column;
      while (issue_mac < c.macs.size() && c.macs[issue_mac].end <= gpu.issue) ++issue_mac;
      if (column && issue_mac < c.macs.size() && c.macs[issue_mac].start <= gpu.issue) {
        const auto& mac = c.macs[issue_mac];
        auto next = c.ready.find(mac.batch+1);
        ++t.issued_mac;
        if (next == c.ready.end()) ++t.issued_final;
        else if (next->second <= gpu.issue) ++t.issued_both;
        else ++t.issued_loading;
      }
      if (!column) continue;
      t.dq += gpu.end-gpu.start;
      while (dq_mac < c.macs.size() && c.macs[dq_mac].end <= gpu.start) ++dq_mac;
      Clock active = 0, both = 0;
      for (size_t i = dq_mac; i < c.macs.size() && c.macs[i].start < gpu.end; ++i) {
        const auto& mac = c.macs[i];
        active += clipped(gpu.start,gpu.end,mac.start,mac.end);
        auto next = c.ready.find(mac.batch+1);
        if (next != c.ready.end())
          both += clipped(gpu.start,gpu.end,std::max(mac.start,next->second),mac.end);
      }
      t.dq_mac += active;
      t.dq_both += both;
      t.bursts_wholly_both += both == gpu.end-gpu.start;
      t.bursts_partly_both += both > 0 && both < gpu.end-gpu.start;
    }
  }

  void finish_g_gap(Channel& s, const PIMController& c, const AddrVec_t& addr, Clock clk,
                    const CommandInfo& m, int gpu_min_group) {
    auto& t = g[s.op];
    ++t.upload_wr;
    if (s.last_wr >= 0) {
      Clock gap_begin = s.last_wr + m.latency + m.burst, gap_end = clk+m.latency;
      Clock gap = gap_end-gap_begin;
      ++t.pairs;
      t.gaps += gap>0;
      t.idle += gap;
      if (s.act_start >= 0 && gap>0) {
        ++t.act_gaps;
        t.act_gap_ck += gap;
        t.mixed_gaps += s.refresh;
        if (s.refresh) t.mixed_ck += gap;
        if (s.act_ready >= 0)
          t.act_window_ck += clipped(gap_begin,gap_end,s.act_start,s.act_ready);
        if (wr_to_rd < 0) {
          auto gpu = addr;
          gpu[1] = 0;
          int rd = c.device.m_spec->get_command_id("RD");
          int wr = c.device.m_spec->get_command_id("WR");
          wr_to_rd = c.spacing(wr,addr,rd,gpu);
          rd_to_wr = c.spacing(rd,gpu,wr,addr);
          wr_to_wr = c.spacing(wr,addr,wr,gpu);
          if (gpu_min_group > 1) {
            read_step = c.spacing(rd,gpu,rd,gpu);
            write_step = c.spacing(wr,gpu,wr,gpu);
          } else {
            read_step = c.device.m_spec->get_timing_value("nCCDS");
            write_step = c.device.m_spec->get_timing_value("nCCDS_WR");
          }
        }
        auto nr = capacity(s.last_wr+wr_to_rd,clk-rd_to_wr,read_step,s.ca);
        auto nw = capacity(s.last_wr+wr_to_wr,clk-wr_to_wr,write_step,s.ca);
        if (nr < static_cast<uint64_t>(gpu_min_group)) nr = 0;
        if (nw < static_cast<uint64_t>(gpu_min_group)) nw = 0;
        t.rd_payload += 2*nr;
        t.wr_payload += 2*nw;
        t.rd_gaps += nr>0;
        t.wr_gaps += nw>0;
        if (!s.refresh) {
          t.clean_rd_payload += 2*nr;
          t.clean_wr_payload += 2*nw;
          t.clean_rd_gaps += nr>0;
          t.clean_wr_gaps += nw>0;
        }
      }
    }
    s.last_wr = clk;
    s.act_start = s.act_ready = -1;
    s.refresh = false;
    s.ca.clear();
  }

  void write(const std::string& path) const {
    std::ofstream out(path);
    if (!g.empty()) {
      out << "operator,pairs,gaps,idle_ck,act_gaps,act_gap_ck,mixed_gaps,mixed_ck,act_window_ck,"
             "rd_payload_ck,wr_payload_ck,rd_gaps,wr_gaps,clean_rd_payload_ck,clean_wr_payload_ck,"
             "clean_rd_gaps,clean_wr_gaps,gpu_columns,upload_wr\n";
      for (const auto& [op,t] : g) {
        out << op;
        for (auto n : {t.pairs,t.gaps,t.idle,t.act_gaps,t.act_gap_ck,t.mixed_gaps,t.mixed_ck,
                       t.act_window_ck,t.rd_payload,t.wr_payload,t.rd_gaps,t.wr_gaps,
                       t.clean_rd_payload,t.clean_wr_payload,t.clean_rd_gaps,t.clean_wr_gaps,
                       t.gpu_columns,t.upload_wr}) out << ',' << n;
        out << '\n';
      }
    } else {
      out << "operator,accepted,columns,issued_mac,issued_both,issued_loading,issued_final,"
             "dq_ck,dq_mac_ck,dq_both_ck,bursts_wholly_both,bursts_partly_both\n";
      for (const auto& [op,t] : e) {
        out << op;
        for (auto n : {t.accepted,t.columns,t.issued_mac,t.issued_both,t.issued_loading,
                       t.issued_final,t.dq,t.dq_mac,t.dq_both,t.bursts_wholly_both,
                       t.bursts_partly_both}) out << ',' << n;
        out << '\n';
      }
    }
    out.close();
    if (!out) std::abort();
  }

public:
  void set_stage(const PIMController& c, const std::string& name) {
    if (!output) return;
    auto& s = channels.at(c.channel);
    finish_e(s);
    if (c.channel == 15 && c.stage == 9) write(std::string(output)+".layer0.csv");
    s.op = name;
    s.fused = c.fused;
    s.stage = c.stage;
    s.tile = 0;
    s.last_fragment = -1;
    s.views = name == "qkv" ? 2 : 1;
    s.gpu.clear();
    s.macs.clear();
    s.ready.clear();
    s.last_wr = s.act_start = s.act_ready = -1;
    s.refresh = false;
    s.ca.clear();
  }

  void issue(const PIMController& c, int cmd, const AddrVec_t& addr, Clock clk,
             Candidate::Source source, int gpu_min_group=1) {
    if (!output || c.stage < 0) return;
    auto& s = channels.at(c.channel);
    const auto& m = c.info[cmd];
    if (!s.fused && source == Candidate::GPU) {
      s.gpu.push_back({clk,clk+m.latency,clk+m.latency+m.burst});
      return;
    }
    if (!operand(s.op) || c.top.issued() || c.descriptor_index>=0) return;
    const auto& op = c.top.ops->at(c.top.next);
    const auto& name = c.device.m_spec->command_names[cmd];
    if (s.fused) {
      if (op.name != "WR" || !op.epoch.ends_with("_input")) return;
      if (source == Candidate::GPU && m.direction &&
          (gpu_min_group==1 || s.last_wr>=0)) ++g[s.op].gpu_columns;
      if (source == Candidate::PIM && name == "WR") {
        finish_g_gap(s,c,addr,clk,m,gpu_min_group);
        return;
      }
      if (s.last_wr < 0) return;
      if (m.external_ca) s.ca.push_back({clk,clk+m.external_ca});
      if (addr[1] != 1) return;
      if (name == "REFab") s.refresh = true;
      if (source == Candidate::PIM && name == "ACT1") s.act_start = clk;
      if (source == Candidate::ACT2 && name == "ACT2")
        s.act_ready = clk+c.device.m_spec->get_timing_value("nRCDWR");
      return;
    }
    if (source != Candidate::PIM) return;
    if (name == "WRGB" && op.epoch.ends_with("_stream")) {
      if (op.tensor_fragment < s.last_fragment) ++s.tile;
      s.last_fragment = op.tensor_fragment;
      if (op.slot % 16 == 15)
        s.ready.emplace(batch_key(s.tile,op.tensor_fragment,s.views),clk+m.completion);
    } else if (name.starts_with("MACAB")) {
      int batch = batch_key(op.output_tile,op.fragment,s.views);
      require(s.ready.at(batch) <= clk,"profile: MAC precedes completed input fill");
      require(s.macs.empty() || s.macs.back().end <= clk,"profile: overlapping MACs");
      s.macs.push_back({clk,clk+m.completion,batch});
    }
  }

  ~GapProfile() {
    if (!output) return;
    for (auto& c : channels) finish_e(c);
    write(output);
  }
};

GapProfile gap_profile;
}
}
