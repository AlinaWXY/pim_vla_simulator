from pathlib import Path
import sys


source, target = map(Path, sys.argv[1:])
code = source.read_text()
grouping = "GpuBurstTag tag;" in code
issue = ("    issue(chosen.cmd,chosen.addr,clk,stage,tag);" if grouping
         else "    issue(chosen.cmd,chosen.addr,clk,stage);")
group_arg = ",gpu_min_group" if grouping else ""
replacements = {
    '#include "ramulator/controller/impl/pim_model.h"':
        '#include "ramulator/controller/impl/pim_model.h"\n#include "gap_profile.h"',
    "  checker.set_stage(clk,stage_id);":
        "  checker.set_stage(clk,stage_id);\n  gap_profile.set_stage(*this,name);",
    "    issue(a.cmd,a.addr,clk,stage);a.cmd=-1;a.deadline=NEVER;return clk;":
        "    const int act2_cmd=a.cmd;\n"
        "    issue(act2_cmd,a.addr,clk,stage);\n"
        f"    gap_profile.issue(*this,act2_cmd,a.addr,clk,Candidate::ACT2{group_arg});\n"
        "    a.cmd=-1;a.deadline=NEVER;return clk;",
    issue: issue + f"\n    gap_profile.issue(*this,chosen.cmd,chosen.addr,clk,chosen.source{group_arg});",
}
for before, after in replacements.items():
    if code.count(before) != 1:
        raise ValueError(f"expected one instrumentation anchor: {before}")
    code = code.replace(before, after)
target.write_text(code)
